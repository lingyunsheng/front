import React from 'react';
import { 
  ListWrapper,
  ListItem,
  List
} from './style';
import LazyLoad from "react-lazyload";
import { withRouter } from 'react-router-dom';

function NewAgeList(props) {
  const enterDetail = (id) => {
    props.history.push(`/recommend/${id}`)
  }
  // const len = props.newAgeList.length-1
  // const arr =[]
  // const classical = props.newAgeList[6]
  // const electornic = props.newAgeList[7]
  // const beatport = props.newAgeList[16]
  // const chan = props.newAgeList[12]
  // const country = props.newAgeList[25]
  // arr.push(classical,electornic,beatport,chan,country)
  // console.log('----arr1',)
  // console.log('----arr',arr)

  return (
    <ListWrapper>
      <h1 className="title">推荐歌单</h1>
      <List>
        {
          props.newAgeList.slice(4,10).map(item => {
            return (
              <ListItem key={item.id} onClick={() => enterDetail(item.id)}>
                <div className="img_wrapper">
                  <div className="decorate"></div>
                  <LazyLoad placeholder={<img width="100%" height="100%" src={require('./music.png')} alt="music"/>}>
                    <img src={item.coverImgUrl + "?param=300x300"} width="100%" height="100%" alt="music"/>
                  </LazyLoad>
                  <div className="play_count">
                    <i className="iconfont play">&#xe885;</i>
                    <span className="count">{Math.floor(item.playCount/10000)}万</span>
                  </div>
                </div>
                <div className="desc">{item.name}</div>
              </ListItem>
            )
          })
        }
      </List>
    </ListWrapper>
  );
  }
 
export default withRouter(React.memo(NewAgeList));