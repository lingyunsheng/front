export const CHANGE_BANNER = "home/recommend/CHANGE_BANNER";

export const CHANGE_RECOMMEND_LIST = "home/recommend/RECOMMEND_LIST";

export const CHANGE_NEWAGE = "home/recommend/CHANGE_NEWAGE";

export const CHANGE_ENTER_LOADING = "home/CHANGE_ENTER_LOADING";
