export const SET_HOT_KEYWRODS = "search/SET_HOT_KEYWRODS";
export const SET_SUGGEST_LIST = 'search/SET_SUGGEST_LIST';
export const SET_RESULT_SONGS_LIST = 'search/SET_RESULT_SONGS_LIST'; 
export const SET_ENTER_LOADING = 'search/SET_ENTER_LOADING'; 